# norwegian-hate-plots
This are the plots resulting the newtork analysis of "Mapping the Evolution of Anti-Muslim Hate Speech in Norwegian Social Media"

The graph code + source data is [here](https://github.com/DTSchroeder/Yuri_Hate_Graphs)

## Updates 

### 14 October 2024

- Pedro things the buttom plots for figure 3 and 5 have to be swaped
    - Moreover we have to change the labels in what is plot 3 (buttom) now and will be plot 5 (buttom) later. 
        - k_i --> w_ij
        - a_i --> h_ij
- For Figure 4 we need a ne plot based on equation 1 the plot
    - is a scatter plot in which every conversation is a point
    - y-axis --> the number of hatefull tweets within a conversation
    - x-axis --> the number of overall tweets within a conversation  

#### Update 

- seems like 3 and 5 do not have to be swapped. Only the label has to be changed.